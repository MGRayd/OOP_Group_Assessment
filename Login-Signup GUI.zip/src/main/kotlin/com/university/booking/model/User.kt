package com.university.booking.model

interface User {
    val username: String
    val password: String
}
